"""
A protocol redefines Bus and Message.
"""

#import j1939
