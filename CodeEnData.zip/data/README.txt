python data is in ascending order:
1: 0.01 time-delay
2: 0.005
3: 0.002
4: 0.001
5: 0.0008
6: 0.0005
7: 0.0002

looci data has the filterpercentage in the filename